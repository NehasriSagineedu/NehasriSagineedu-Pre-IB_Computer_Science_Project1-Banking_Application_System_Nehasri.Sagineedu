package bankingapplication; // Used to group the related BankApplication class with the BankingAccount class.

import java.util.Scanner; // Explicit scanner import.
import java.util.UUID; // Importing a class that generates a universally unique identifier (UUID) or customer ID for the user.


// This class stores all the five operations (check balance, deposit, withdraw, check previous transaction, and exit) that can be selected by the user.
public class BankAccount {

        int balance; // Integer variable: balance = the money which is in the account.
        int previousTransaction; // Integer variable: previous transaction = indicates whether the last amount is deposited or withdrawn and the amount too.
        String customerName; // String variable: customer name = the customer's name which will be an input into the program by the user.


        // This is the constructor for the class BankAccount, and it has no return type.
        // While creating the object of the class BankAccount, this value of the customer's name is going to be passed by one value in the constructor.
        BankAccount(String cname)
        // The customer name is being taken as a parameter by the constructor, because this information is needed to display the welcome message for the user.
        // Parameter: cname = the name of the customer
        {
            customerName = cname; // Assigning the value.
        }


        // This is the deposit method, which takes one integer as a parameter through the "amount" parameter.
        // amount = refers to the sum of money that will be deposited into the bank account.
        void deposit(int amount)
        {
            // The operation should not occur if the value entered by the user is zero, and hence an "if" statement is used to create a check for the input.
            if(amount != 0)
            {
                balance = balance + amount; // The balance variable is updated by incrementing its value with the amount parameter.
                previousTransaction = amount; // The amount value is assigned to the previous transaction variable in order to know the sum of money that is deposited by the user.
            }
        }


    // This is the withdrawing method, which takes one integer as a parameter through the "amount" parameter.
    // amount = refers to the sum of money that will be deposited into the bank account.
        void withdraw(int amount)
        {
            // The operation should not occur if the value entered by the user is zero, and hence an "if" statement is used to create a check for the input.
            if (amount != 0)
            {
                balance = balance - amount; // The balance variable is updated by decrementing its value with the amount parameter.
                previousTransaction = -amount; // The minus symbol indicates to the user that a withdrawal has occurred.
            }
        }


        // This is the previous transaction method, which will inform the user whether the money is deposited or withdrawn, and the amount of money dealt with.
        void getPreviousTransaction()
        {
            // This check is indicating that if the amount of money is greater than zero, the user has made a deposit.
            if (previousTransaction > 0)
            {
                System.out.println("Deposited: " + previousTransaction); // Displays the value of money deposited to the user.
            }
            // This check is indicating that if the amount of money is less than zero, the user had made a withdrawal.
            else if (previousTransaction < 0)
            {
                System.out.println("Withdrawn: " + Math.abs(previousTransaction)); // Displays the value of money withdraw to the user.
                // Math.abs function is used in order to give the absolute value of the negative number, rather than displaying "Withdrawn: -number".
            }
            // This check is indicating that if there was no previous transaction that had occurred, it will display a message to the user.
            else
            {
                System.out.println("No Transaction..."); // Displays that no transaction has occurred to the user.
            }
        }


        // This is the show menu method, which will display the five options of the banking system to the user.
        void showMenu()
        {
            char option = '\0'; // Char variable: option = has been initialized with a null character, which marks the end of a character string
            Scanner userInput = new Scanner(System.in); // This scanner object has been created to take the user's input into the program.

            // This is the welcome message that will be displayed after the user has entered their name into the program.
            System.out.println("Hi " + customerName + ", this is your personalized banking application.");
            UUID customerID = UUID.randomUUID(); // A universally unique customer ID is generated by using this method that can randomly assign values.
            System.out.println("Your universal customer ID is: " + customerID); // Displays the unique customer ID to the user.
            System.out.println("Please do not share your customer ID with anyone for security reasons!");
            System.out.println("\n"); // Creates a line break or space after the above message is printed.

            // These five options that can be selected by the user will be displayed as a part of the banking application.
            System.out.println("Option A: Check Your Balance");
            System.out.println("Option B: Deposit");
            System.out.println("Option C: Withdraw");
            System.out.println("Option D: Previous Transaction");
            System.out.println("Option E: Exit the System");


            // This do-while loop allows the program to perform these set of statements below, while the option is not equal to E.
            // Option E represents "exit", which means that whenever the user enters the alphabet "E" into the program, this loop will break.
            do
            {
                System.out.println("__________________________________"); // This is used for creating a neat display for the user, and is only purposed for the aesthetics of the program.
                System.out.println("Please enter your preferred option for our banking system."); // Asks the user to enter an option out of the five choices given.
                System.out.println("__________________________________");
                option = userInput.next().charAt(0); // The user will be entering a character as the input, and it will be captured by the option variable.
                System.out.println("\n");


                // The option variable is passed into the switch case.
                // The option variable will be compared with each of the cases below, and whenever it finds a match, it will execute the corresponding code.
                switch (option)
                {
                    case 'A': // Case A executes the action of checking the balance in the account.
                        System.out.println("============================="); // This is used for creating a neat display for the user, and is only purposed for the aesthetics of the program.
                        System.out.println("Your Balance: " + balance); // The integer variable balance is used for displaying the sum of money to the user.
                        System.out.println("=============================");
                        System.out.println("\n"); // Creates a line break or space.
                        break;

                    case 'B': // Case B executes the action of allowing the user to deposit a certain sum of money into their account.
                        System.out.println("=============================");
                        System.out.println("Please Enter an Amount to Deposit: "); // Asks the user to enter an amount to deposit.
                        System.out.println("=============================");

                        // This try statement defines a block to be tested for errors while it is being executed.
                        // Errors include if the user had entered a double value, or any other character other than an integer value.
                        // Uses the scanner as a resource, and the scanner itself uses the (System.in) as a resource.
                        try {
                            int amount = userInput.nextInt(); // Uses the scanner object to take the input of the user, and the value that is received will be placed into the amount variable.
                            deposit(amount); // The amount variable is passed into the deposit method, which will then perform its operations coded.
                            System.out.println("\n");
                            break; // This break is a part of the syntax of the switch case.
                        } // Once the try block is reached, the scanner instance closes its resource, (System.in), and therefore the program will not get any input from the user.
                        // This catch statement defines a block of code to be executed if an error occurs in the try block.
                        // If an exception is caught, an "exception caught" message will be printed, and it will exit the program.
                        catch (Exception e) {
                            System.out.println("Exception caught in option B: " + e);
                            System.exit(1);
                        }

                    case 'C': // Case C executes the action of allowing the user to withdraw a certain sum of money from their account.
                        System.out.println("=============================");
                        System.out.println("Please Enter an Amount to Withdraw: "); // Asks the user to enter an amount to withdraw.
                        System.out.println("=============================");

                        try {
                            int amount2 = userInput.nextInt(); // Uses the scanner object to take the input of the user, and the value that is received will be placed into the amount2 variable.
                            withdraw(amount2); // The amount2 variable is passed into the withdrawal method, which will then perform its operations coded.
                            System.out.println("\n");
                            break;
                        } catch (Exception e) {
                            System.out.println("Exception caught in option C: " + e);
                            System.exit(1);
                        }

                    case 'D': // Case D executes the action of displaying the last deposit or withdrawal value to the user.
                        System.out.println("=============================");
                        getPreviousTransaction(); // Calls the get previous transaction method.
                        System.out.println("=============================");
                        System.out.println("\n");
                        break;

                    case 'E': // Case E executes the action of exiting the user from the program.
                        System.out.println("__________________________________");
                        System.out.println("Thank you for using Sagineedu banking services! We hope to see you again soon.");
                        System.out.println("__________________________________");
                        break;

                    default: // This default case will execute a block of code if the user enters a character that does not belong to any of the cases above.
                        System.out.println("Invalid option! Please enter a correct option from the choices provided."); // This message will be displayed that makes the user to enter a correct option from the choices.
                        break;
                }

            }
            // When the user enters option E of exiting the program, this coded loop will break.
            while(option != ('E'));
        }

}
